﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nepesseg.Entities
{
    class BirthProbability
    {
       // kor, gyermekek száma és a valószínűség

             public int Age { get; set; }
             public byte NumberOfChilden { get; set; }
             public double P { get; set; }
    }
}
