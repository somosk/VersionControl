﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wwek06.Entities
{
    class Currency
    {
        public string CValue { get; set; }
    }
}
